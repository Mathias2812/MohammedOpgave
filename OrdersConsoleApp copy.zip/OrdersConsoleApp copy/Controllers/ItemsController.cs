﻿using OrdersConsoleApp.Models;
using OrdersConsoleApp.Repositories;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersConsoleApp.Controllers
{
    public class ItemsController
    {
       ItemsRepository repository;
        public ItemsController()
        {
            repository = new ItemsRepository();
        }

        public IEnumerable<Item> GetItems()
        {
            var items = repository.getItems();
            return items;
        }

        public Item GetSelectedItem(string id)
        {
            var item = repository.getItem(id);
            return item;
        }

        public void newitem(string  id, string name, double price)
        {
            Item item = new Item()
            {
                ItemId = id,
                Name = name,
                Price = price
            };
            repository.insertItem(item);
            
        }
    }
}
