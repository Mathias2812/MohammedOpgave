﻿
using MongoDB.Driver;
using OrdersConsoleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersConsoleApp.Repositories
{
    public  class OrdersRepository
    {
        private string connectionString = "mongodb+srv://Mathias:WIo1Ur96HmbePGvm@cluster1.xzjj3.mongodb.net/";

        IMongoClient mongoClient;

        IMongoDatabase database;

        IMongoCollection<Order> collection;

        public OrdersRepository()
        {
            mongoClient = new MongoClient(connectionString);

            database = mongoClient.GetDatabase("OrdersDB");

            collection = database.GetCollection<Order>("Orders");
        }

            public void insertOneOrder(Order order)
            {
                collection.InsertOne(order);
            }
            

        }
}
