﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrdersConsoleApp.Models
{
    public  class Order
    { 
        public ObjectId  Id { get; set; }
        public DateTime  Date { get; set; }       
        public Customer Customer { get; set; }
        public List<Item>? ShoppingCart { get; set;}= new List<Item>();

        public double  calculateTotalAmount()
        {
            // implement this method
            return 0;
        }

        public void AddItem(Item item)
        {
            // implement this method
        }
    }
}
